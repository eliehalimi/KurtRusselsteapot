# include "gui.h"

struct system *init_system(int w, int h)
{
  struct system *sys;
  //system created
  sys = new_system(3);
  sys->camera = new_camera(w / 2, h / 2);
  sys->delta_time = 0.1f;
  
  return sys;
}

void init_draw_list(struct htable *draw_list)
{
  add_htable(draw_list, "startmenu", malloc(sizeof(int)));  
  add_htable(draw_list, "optionmenu", malloc(sizeof(int)));
  add_htable(draw_list, "creditmenu", malloc(sizeof(int)));
  add_htable(draw_list, "namemenu", malloc(sizeof(int)));
  add_htable(draw_list, "mainmenu", malloc(sizeof(int)));
  add_htable(draw_list, "pausemenu", malloc(sizeof(int)));
  add_htable(draw_list, "loadmenu", malloc(sizeof(int)));
  add_htable(draw_list, "warning_loadmenu", malloc(sizeof(int)));
  add_htable(draw_list, "volumemenu", malloc(sizeof(int)));

  *((int *)(access_htable(draw_list, "startmenu")->value)) = 1;
  *((int *)(access_htable(draw_list, "creditmenu")->value)) = 0;
  *((int *)(access_htable(draw_list, "namemenu")->value)) = 0;
  *((int *)(access_htable(draw_list, "mainmenu")->value)) = 0;
  *((int *)(access_htable(draw_list, "pausemenu")->value)) = 0;
  *((int *)(access_htable(draw_list, "volumemenu")->value)) = 0;
  *((int *)(access_htable(draw_list, "optionmenu")->value)) = 0;  
  *((int *)(access_htable(draw_list, "loadmenu")->value)) = 0;  
  *((int *)(access_htable(draw_list, "warning_loadmenu")->value)) = 0;  

}

void init_text(struct htable *text_list, char *name, int size, int item)
{
  add_htable(text_list, name, malloc(sizeof(struct text)));
  struct text *text = (struct text *)(access_htable(text_list, name)->value);
  text->text = malloc(size*sizeof(char));
  *(text->text) = '\0';
  text->nbchar = 0;
  text->active = 0;
  text->item = item;
}
void init_text_list(struct htable *text_list)
{
  init_text(text_list, "name", 30, 0);
  init_text(text_list, "name_loadmenu", 30, 0);
  init_text(text_list, "warning_loadmenu", 200, 0);
  init_text(text_list, "intro", 200, 0);
  init_text(text_list, "item_name", 20, 1);
  init_text(text_list, "item_x", 20, 1);
  init_text(text_list, "item_y", 20, 1);
  init_text(text_list, "item_z", 20, 1);
  init_text(text_list, "item_mass", 20, 1);
  init_text(text_list, "item_radius", 20, 1);
  init_text(text_list, "item_vx", 20, 1);
  init_text(text_list, "item_vy", 20, 1);
  init_text(text_list, "item_vz", 20, 1);
}
void init_lists(int w, int h, struct htable *button_list, struct htable *window_list, struct htable *img_list, struct htable *draw_list, struct htable *text_list, struct htable *slider_list, struct palette *p)
{
  
        init_draw_list(draw_list);
        init_text_list(text_list);

	add_htable(button_list, "new", malloc(sizeof(struct button)));
	add_htable(button_list, "load", malloc(sizeof(struct button)));
	add_htable(button_list, "option", malloc(sizeof(struct button)));
	add_htable(button_list, "quit", malloc(sizeof(struct button)));
	add_htable(window_list, "startmenu", malloc(sizeof(struct window)));

	add_htable(button_list, "credit", malloc(sizeof(struct button)));
	add_htable(button_list, "volume", malloc(sizeof(struct button)));
	add_htable(button_list, "back_optionmenu", malloc(sizeof(struct button)));
	add_htable(window_list, "optionmenu", malloc(sizeof(struct window)));
	
	add_htable(window_list, "creditmenu", malloc(sizeof(struct window)));
	add_htable(button_list, "back_creditmenu", malloc(sizeof(struct button)));

	add_htable(window_list, "volumemenu", malloc(sizeof(struct window)));
	add_htable(button_list, "back_volumemenu", malloc(sizeof(struct button)));
	add_htable(slider_list, "music_volumemenu", malloc(sizeof(struct slider)));
	add_htable(slider_list, "effect_volumemenu", malloc(sizeof(struct slider)));

	add_htable(button_list, "x", malloc(sizeof(struct button)));
	add_htable(button_list, "start", malloc(sizeof(struct button)));
	add_htable(window_list, "namemenu", malloc(sizeof(struct window)));

	add_htable(button_list, "pause", malloc(sizeof(struct button)));
	add_htable(button_list, "item_name", malloc(sizeof(struct button)));
	add_htable(button_list, "item_x", malloc(sizeof(struct button)));
	add_htable(button_list, "item_y", malloc(sizeof(struct button)));
	add_htable(button_list, "item_z", malloc(sizeof(struct button)));
	add_htable(button_list, "item_mass", malloc(sizeof(struct button)));
	add_htable(button_list, "item_radius", malloc(sizeof(struct button)));
	add_htable(button_list, "item_vx", malloc(sizeof(struct button)));
	add_htable(button_list, "item_vy", malloc(sizeof(struct button)));
	add_htable(button_list, "item_vz", malloc(sizeof(struct button)));
	add_htable(button_list, "add", malloc(sizeof(struct button)));
	add_htable(button_list, "delete", malloc(sizeof(struct button)));
	add_htable(button_list, "start_mainmenu", malloc(sizeof(struct button)));
	add_htable(slider_list, "timelapse", malloc(sizeof(struct slider)));

	add_htable(window_list, "mainmenu", malloc(sizeof(struct window)));
	add_htable(window_list, "itemsmenu", malloc(sizeof(struct window)));
	
	add_htable(button_list, "resume", malloc(sizeof(struct button)));
	add_htable(button_list, "quit_mainmenu", malloc(sizeof(struct button)));
	add_htable(button_list, "reset", malloc(sizeof(struct button)));
	add_htable(button_list, "saveandquit", malloc(sizeof(struct button)));
	add_htable(window_list, "pausemenu", malloc(sizeof(struct window)));
	add_htable(slider_list, "music_pausemenu", malloc(sizeof(struct slider)));
	add_htable(slider_list, "effect_pausemenu", malloc(sizeof(struct slider)));


	add_htable(button_list, "x_loadmenu", malloc(sizeof(struct button)));
	add_htable(button_list, "start_loadmenu", malloc(sizeof(struct button)));
	add_htable(window_list, "loadmenu", malloc(sizeof(struct window)));
	add_htable(slider_list, "scrollbar", malloc(sizeof(struct slider)));


	
	window_new(access_htable(window_list, "startmenu")->value, access_htable(img_list, "startmenu")->value, 0, 0, w, h, NULL);
	button_new(access_htable(button_list, "new")->value, access_htable(img_list,"new_selected")->value, access_htable(img_list, "new_unselected")->value, 400, 320, access_htable(window_list, "startmenu")->value);
	button_new(access_htable(button_list, "load")->value, access_htable(img_list,"load_selected")->value, access_htable(img_list,"load_unselected")->value, 400, 415, access_htable(window_list, "startmenu")->value);
	button_new(access_htable(button_list, "option")->value, access_htable(img_list,"options_selected")->value, access_htable(img_list,"options_unselected")->value, 400, 510, access_htable(window_list, "startmenu")->value);
	button_new(access_htable(button_list, "quit")->value, access_htable(img_list,"quit_selected")->value, access_htable(img_list,"quit_unselected")->value, 400, 605, access_htable(window_list, "startmenu")->value);

	
	window_new(access_htable(window_list, "optionmenu")->value, access_htable(img_list,"optionmenu")->value, 0, 0, w, h, NULL);
	button_new(access_htable(button_list, "credit")->value, access_htable(img_list,"credit_selected")->value, access_htable(img_list,"credit_unselected")->value, 400, 300, access_htable(window_list, "optionmenu")->value);
	button_new(access_htable(button_list, "volume")->value, access_htable(img_list,"volume_selected")->value, access_htable(img_list,"volume_unselected")->value, 400, 400, access_htable(window_list, "optionmenu")->value);
	button_new(access_htable(button_list, "back_optionmenu")->value, access_htable(img_list,"back_selected")->value, access_htable(img_list,"back_unselected")->value,400,600, access_htable(window_list, "optionmenu")->value);

	
	window_new(access_htable(window_list, "creditmenu")->value, access_htable(img_list,"creditmenu")->value, 0, 0, w, h, NULL);
	button_new(access_htable(button_list, "back_creditmenu")->value, access_htable(img_list,"back_selected")->value, access_htable(img_list,"back_unselected")->value, 400, 600, access_htable(window_list, "creditmenu")->value);

	window_new(access_htable(window_list, "volumemenu")->value, access_htable(img_list,"volumemenu")->value, 0, 0, w, h, NULL);
	button_new(access_htable(button_list, "back_volumemenu")->value, access_htable(img_list,"back_selected")->value, access_htable(img_list,"back_unselected")->value, 400, 600, access_htable(window_list, "volumemenu")->value);
	int *max1 =malloc(sizeof(int)), *min1 = malloc(sizeof(int));
	*max1 = MIX_MAX_VOLUME;
	*min1 = 0;
	slider_new(access_htable(slider_list, "music_volumemenu")->value, access_htable(img_list,"music_volumemenu")->value, access_htable(img_list,"token_slider_selected")->value, access_htable(img_list,"token_slider_unselected")->value, 1, 480, 220, 28, access_htable(window_list, "volumemenu")->value, max1, min1);
        slider_new(access_htable(slider_list, "effect_volumemenu")->value, access_htable(img_list,"effect_volumemenu")->value, access_htable(img_list,"token_slider_selected")->value, access_htable(img_list,"token_slider_unselected")->value, 1, 480, 390, 28, access_htable(window_list, "volumemenu")->value, max1, min1);

	window_new(access_htable(window_list, "namemenu")->value, access_htable(img_list,"namemenu")->value, 260, 200, 739, 300, NULL);
	button_new(access_htable(button_list, "x")->value, access_htable(img_list,"x_selected")->value, access_htable(img_list,"x_unselected")->value, 945, 205, access_htable(window_list, "namemenu")->value);
	button_new(access_htable(button_list, "start")->value, access_htable(img_list,"start_selected")->value, access_htable(img_list,"start_unselected")->value, 500, 400, access_htable(window_list, "namemenu")->value);

	
	window_new(access_htable(window_list, "mainmenu")->value, access_htable(img_list,"mainmenu")->value, 0, 0, w, h, NULL);
	window_new(access_htable(window_list, "itemsmenu")->value, access_htable(img_list,"itemsmenu")->value,
		   1053, 44, ITEM_MENU_WIDTH, ITEM_MENU_HEIGHT, access_htable(window_list, "mainmenu")->value);
	button_new(access_htable(button_list, "pause")->value, access_htable(img_list,"pause_selected")->value, access_htable(img_list,"pause_unselected")->value, 0, 0, access_htable(window_list, "mainmenu")->value);
	button_new(access_htable(button_list, "item_name")->value, access_htable(img_list,"item_namebox_selected")->value, access_htable(img_list,"item_namebox_unselected")->value, 1073, 68, access_htable(window_list, "itemsmenu")->value);
	button_new(access_htable(button_list, "item_x")->value, access_htable(img_list,"item_posbox_selected")->value, access_htable(img_list,"item_posbox_unselected")->value, 1095, 130, access_htable(window_list, "itemsmenu")->value);
	button_new(access_htable(button_list, "item_y")->value, access_htable(img_list,"item_posbox_selected")->value, access_htable(img_list,"item_posbox_unselected")->value, 1095, 158, access_htable(window_list, "itemsmenu")->value);
	button_new(access_htable(button_list, "item_z")->value, access_htable(img_list,"item_posbox_selected")->value, access_htable(img_list,"item_posbox_unselected")->value, 1095, 186, access_htable(window_list, "itemsmenu")->value);
	button_new(access_htable(button_list, "item_mass")->value, access_htable(img_list,"item_posbox_selected")->value, access_htable(img_list,"item_posbox_unselected")->value, 1090, 239, access_htable(window_list, "itemsmenu")->value);
	button_new(access_htable(button_list, "item_radius")->value, access_htable(img_list,"item_posbox_selected")->value, access_htable(img_list,"item_posbox_unselected")->value, 1090, 289, access_htable(window_list, "itemsmenu")->value);
	button_new(access_htable(button_list, "item_vx")->value, access_htable(img_list,"item_posbox_selected")->value, access_htable(img_list,"item_posbox_unselected")->value, 1090, 340, access_htable(window_list, "itemsmenu")->value);
	button_new(access_htable(button_list, "item_vy")->value, access_htable(img_list,"item_posbox_selected")->value, access_htable(img_list,"item_posbox_unselected")->value, 1090, 368, access_htable(window_list, "itemsmenu")->value);
	button_new(access_htable(button_list, "item_vz")->value, access_htable(img_list,"item_posbox_selected")->value, access_htable(img_list,"item_posbox_unselected")->value, 1090, 396, access_htable(window_list, "itemsmenu")->value);

	float *maxval =malloc(sizeof(float)), *minval = malloc(sizeof(float));
	*maxval = 4.0f;
	*minval = 0.1f;
	slider_new(access_htable(slider_list, "timelapse")->value, access_htable(img_list,"timelapse")->value, access_htable(img_list,"token_slider_selected")->value, access_htable(img_list,"token_slider_unselected")->value, 1, 1060, 432, 7, access_htable(window_list, "itemsmenu")->value, maxval, minval);
	palette_new(p, access_htable(window_list, "itemsmenu")->value, 1065, 495, 210, 5, 12, 2);
	
	button_new(access_htable(button_list, "reset")->value, access_htable(img_list,"reset_selected")->value, access_htable(img_list,"reset_unselected")->value, 1090, 517, access_htable(window_list, "itemsmenu")->value);

	button_new(access_htable(button_list, "add")->value, access_htable(img_list,"add_selected")->value, access_htable(img_list,"add_unselected")->value, 1090, 570, access_htable(window_list, "itemsmenu")->value);
	button_new(access_htable(button_list, "start_mainmenu")->value, access_htable(img_list,"start_mainmenu_selected")->value, access_htable(img_list,"start_mainmenu_unselected")->value, 1090, 615, access_htable(window_list, "itemsmenu")->value);
	button_new(access_htable(button_list, "delete")->value, access_htable(img_list,"delete_selected")->value, access_htable(img_list,"delete_unselected")->value, 1090, 665, access_htable(window_list, "itemsmenu")->value);

	
	window_new(access_htable(window_list, "pausemenu")->value, access_htable(img_list,"pausemenu")->value, 0, 44, 227,676, access_htable(window_list, "mainmenu")->value);
	button_new(access_htable(button_list, "resume")->value, access_htable(img_list,"resume_selected")->value, access_htable(img_list,"resume_unselected")->value, 30, 90, access_htable(window_list, "pausemenu")->value);
	button_new(access_htable(button_list, "saveandquit")->value, access_htable(img_list,"saveandquit_selected")->value, access_htable(img_list,"saveandquit_unselected")->value, 15, 160, access_htable(window_list, "pausemenu")->value);
	button_new(access_htable(button_list, "quit_mainmenu")->value, access_htable(img_list,"quit_mainmenu_selected")->value, access_htable(img_list,"quit_mainmenu_unselected")->value, 30, 230, access_htable(window_list, "pausemenu")->value);

	slider_new(access_htable(slider_list, "music_pausemenu")->value, access_htable(img_list,"music_pausemenu")->value, access_htable(img_list,"token_slider_selected")->value, access_htable(img_list,"token_slider_unselected")->value, 1, 10, 340, 7, access_htable(window_list, "pausemenu")->value, max1, min1);
        slider_new(access_htable(slider_list, "effect_pausemenu")->value, access_htable(img_list,"effect_pausemenu")->value, access_htable(img_list,"token_slider_selected")->value, access_htable(img_list,"token_slider_unselected")->value, 1, 10, 400, 7, access_htable(window_list, "pausemenu")->value, max1, min1);	
	
	
	window_new(access_htable(window_list, "loadmenu")->value, access_htable(img_list,"loadmenu")->value, 259, 80, 763, 575, NULL);
	button_new(access_htable(button_list, "x_loadmenu")->value, access_htable(img_list,"x_selected")->value, access_htable(img_list,"x_unselected")->value, 968, 80, access_htable(window_list, "loadmenu")->value);
	button_new(access_htable(button_list, "start_loadmenu")->value, access_htable(img_list,"start_selected")->value, access_htable(img_list,"start_unselected")->value, 510, 570, access_htable(window_list, "loadmenu")->value);	
	
	int *max_sb =malloc(sizeof(int)), *min_sb = malloc(sizeof(int));
	*max_sb = 10;
	*min_sb = 0;
	slider_new(access_htable(slider_list, "scrollbar")->value, access_htable(img_list,"scrollbar")->value, access_htable(img_list,"token_scrollbar_selected")->value, access_htable(img_list,"token_scrollbar_unselected")->value, 0, 952, 118, 0, access_htable(window_list, "loadmenu")->value, max_sb, min_sb);


	((struct button *)(access_htable(button_list, "item_name")->value))->textbox = 1;
	((struct button *)(access_htable(button_list, "item_x")->value))->textbox = 1;
	((struct button *)(access_htable(button_list, "item_y")->value))->textbox = 1;
	((struct button *)(access_htable(button_list, "item_z")->value))->textbox = 1;
	((struct button *)(access_htable(button_list, "item_mass")->value))->textbox = 1;
	((struct button *)(access_htable(button_list, "item_radius")->value))->textbox = 1;
	((struct button *)(access_htable(button_list, "item_vx")->value))->textbox = 1;
	((struct button *)(access_htable(button_list, "item_vy")->value))->textbox = 1;
	((struct button *)(access_htable(button_list, "item_vz")->value))->textbox = 1;

}

