# ifndef COLLISION_STARDWARF
# define COLLISION_STARDWARF

#include <stdlib.h>
#include "libvector.h"
#include "physic.h"

void collide(struct item *i1, struct item *i2); 
# endif
